import React from "react";
import "./Carousel_Cont.css";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import car1 from "../../../Images/Carousel/image 31.png";

const Carousel_Cont = () => {
  return (
    <div className="carousel-container">
      <p>
        Welcome to JusVouchers - Bhopal Trusted Coupons, Offers & Cashback
        Website
      </p>
      <Carousel
        autoPlay
        infiniteLoop
        showArrows={false}
        showThumbs={false}
        showStatus={false}
        renderIndicator={(onClickHandler, isSelected, index, label) => {
          const defStyle = { width: 5, color: "white", cursor: "pointer" };
          const style = isSelected
            ? { ...defStyle, color: "yellow" }
            : { ...defStyle };

          return (
            <span
              style={style}
              onClick={onClickHandler}
              onKeyDown={onClickHandler}
              value={index}
              key={index}
              role="button"
              tabIndex={0}
              aria-label={`${label} ${index + 1}`}
            >
              <input type={"radio"} />
            </span>
          );
        }}
      >  
          <div className="carou">
            <img src={car1} />
          </div>
          <div className="carou">
            <img src={car1} />
          </div>
          <div className="carou">
            <img src={car1} />
          </div>
        
      </Carousel>
    </div>
  );
};

export default Carousel_Cont;
